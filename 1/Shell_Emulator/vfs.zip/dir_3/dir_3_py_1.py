print("          Chess or Chekers?\nIf (you select Chess):\n     display the contents of the file dir_3_text_2.txt\nElse:\n     display the contents of the file dir_3_text_3.txt")
